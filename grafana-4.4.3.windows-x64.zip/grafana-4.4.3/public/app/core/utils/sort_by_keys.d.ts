export default function sortByKeys(input: any): any;
