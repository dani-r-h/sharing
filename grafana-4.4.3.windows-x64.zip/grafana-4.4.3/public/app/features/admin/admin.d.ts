import './adminListOrgsCtrl';
import './adminEditOrgCtrl';
import './adminEditUserCtrl';
export declare class AdminStatsCtrl {
    stats: any;
    navModel: any;
    /** @ngInject */
    constructor(backendSrv: any, navModelSrv: any);
}
