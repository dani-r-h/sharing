
export class AnnotationEvent {
  dashboardId: number;
  panelId: number;
  time: any;
  timeEnd: any;
  isRegion: boolean;
  title: string;
  text: string;
}
